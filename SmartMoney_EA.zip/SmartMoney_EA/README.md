# 📈 SmartMoney EA — MQL5 Trading Robot

> A professional Smart Money Concepts (SMC) trading robot for MetaTrader 5, implementing Fair Value Gaps (FVG), Liquidity Detection, and Break of Structure (BOS) with automated Buy/Sell signals.

![MQL5](https://img.shields.io/badge/Platform-MetaTrader%205-blue)
![Language](https://img.shields.io/badge/Language-MQL5-orange)
![Strategy](https://img.shields.io/badge/Strategy-Smart%20Money%20Concepts-green)
![License](https://img.shields.io/badge/License-MIT-lightgrey)

---

## 🧠 Strategy Overview

This EA is built on **Smart Money Concepts (SMC)** — a price action methodology that follows institutional order flow by identifying:

| Concept | Description |
|--------|-------------|
| **FVG** | Fair Value Gaps — imbalances left by impulsive moves |
| **Liquidity** | Equal Highs/Lows, Buy-side & Sell-side pools |
| **BOS** | Break of Structure — confirms trend direction |
| **CHoCH** | Change of Character — early trend reversal signal |

### Signal Logic (Confluence Required)

**BUY Signal triggers when:**
- ✅ Bullish BOS confirmed (price broke above last swing high)
- ✅ Price enters a bullish Fair Value Gap
- ✅ Sell-side liquidity nearby (price swept or approaching SSL)

**SELL Signal triggers when:**
- ✅ Bearish BOS confirmed (price broke below last swing low)
- ✅ Price enters a bearish Fair Value Gap
- ✅ Buy-side liquidity nearby (price swept or approaching BSL)

---

## 📂 Project Structure

```
SmartMoney_EA/
├── MQL5/
│   ├── Experts/
│   │   └── SmartMoney_EA.mq5         # Main EA file
│   └── Include/
│       └── SmartMoney/
│           ├── FVG.mqh               # Fair Value Gap detection
│           ├── Liquidity.mqh         # Liquidity zone finder
│           ├── BOS.mqh               # Break of Structure detector
│           └── SignalEngine.mqh      # Signal confluence engine
├── docs/
│   └── strategy_guide.md            # Detailed strategy explanation
└── README.md
```

---

## 🚀 Installation

1. **Clone the repo**
   ```bash
   git clone https://github.com/YOUR_USERNAME/SmartMoney_EA.git
   ```

2. **Copy files to MT5**
   - Copy `MQL5/Experts/SmartMoney_EA.mq5` → `[MT5 Data Folder]/MQL5/Experts/`
   - Copy `MQL5/Include/SmartMoney/` → `[MT5 Data Folder]/MQL5/Include/SmartMoney/`

3. **Find your MT5 Data Folder**
   - In MT5: `File → Open Data Folder`

4. **Compile**
   - Open MetaEditor (F4 in MT5)
   - Open `SmartMoney_EA.mq5`
   - Press `F7` to compile
   - Fix any errors (should be none)

5. **Attach to Chart**
   - Drag EA from Navigator panel onto any chart
   - Configure inputs (see below)
   - Enable `AutoTrading` in MT5 toolbar

---

## ⚙️ Input Parameters

### Risk Management
| Parameter | Default | Description |
|-----------|---------|-------------|
| `InpRiskPercent` | 1.0 | Risk % of account per trade |
| `InpRRRatio` | 2.0 | Risk:Reward ratio for TP |
| `InpMaxTrades` | 3 | Maximum concurrent open trades |

### Structure Settings
| Parameter | Default | Description |
|-----------|---------|-------------|
| `InpStructureLookback` | 50 | Bars to scan for BOS |
| `InpFVGMinGap` | 5 | Minimum FVG size in points |
| `InpLiquidityBars` | 20 | Swing lookback for liquidity |

### Display Settings
| Parameter | Default | Description |
|-----------|---------|-------------|
| `InpShowFVG` | true | Draw FVG zones on chart |
| `InpShowLiquidity` | true | Draw liquidity levels |
| `InpShowBOS` | true | Draw BOS/CHoCH labels |
| `InpShowSignals` | true | Draw buy/sell arrows |
| `InpAutoTrade` | true | Enable live order execution |

---

## 📊 Visual Indicators on Chart

| Object | Meaning |
|--------|---------|
| 🟢 Up Arrow | **BUY** signal |
| 🔴 Down Arrow | **SELL** signal |
| 🟦 Blue Rectangle | Bullish FVG zone (BFVG) |
| 🟧 Orange Rectangle | Bearish FVG zone (SFVG) |
| 🟡 Gold Dotted Line | Liquidity level (BSL/SSL) |
| 🟢 Green Dashed Line | Bullish BOS level |
| 🔴 Red Dashed Line | Bearish BOS level |
| **CHoCH** label | Change of Character (trend flip) |
| **BOS** label | Break of Structure (trend continuation) |

---

## 📈 Recommended Settings

| Pair | Timeframe | Notes |
|------|-----------|-------|
| XAUUSD | M15 / H1 | Best for SMC, high liquidity |
| EURUSD | M15 / H1 | Clean structure |
| GBPUSD | H1 | High volatility, wide SLs |
| US30 | M15 | Strong trend movements |

**Tips:**
- Use **H4 or D1 for bias** and **M15 for entries**
- Works best during **London & NY sessions**
- Avoid trading during major **news events**

---

## 🛡️ Risk Warning

> This EA is provided for **educational purposes only**. Forex and CFD trading involves significant risk. Past performance does not guarantee future results. Always test on a **demo account** before going live. Never risk money you cannot afford to lose.

---

## 🤝 Contributing

Pull requests are welcome! For major changes, please open an issue first.

1. Fork the repo
2. Create your branch: `git checkout -b feature/my-feature`
3. Commit: `git commit -m 'Add my feature'`
4. Push: `git push origin feature/my-feature`
5. Open a Pull Request

---

## 📜 License

MIT License — see [LICENSE](LICENSE) for details.

---

## ⭐ Support

If this helped you, please **star the repo** ⭐ — it helps others find it!
