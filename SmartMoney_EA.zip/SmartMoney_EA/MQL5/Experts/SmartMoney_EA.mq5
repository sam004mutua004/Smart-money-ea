//+------------------------------------------------------------------+
//|                                               SmartMoney_EA.mq5  |
//|                        Smart Money Concepts Trading Robot         |
//|         Concepts: FVG | Liquidity | BOS | Buy & Sell Signals     |
//+------------------------------------------------------------------+
#property copyright   "SmartMoney EA"
#property version     "1.00"
#property strict
#property description "Smart Money Concepts EA — FVG, Liquidity, BOS Detection"

#include <SmartMoney/FVG.mqh>
#include <SmartMoney/Liquidity.mqh>
#include <SmartMoney/BOS.mqh>
#include <SmartMoney/SignalEngine.mqh>
#include <Trade/Trade.mqh>

//--- Input Parameters
input group "=== RISK MANAGEMENT ==="
input double InpRiskPercent     = 1.0;       // Risk % per trade
input double InpRRRatio         = 2.0;       // Risk:Reward ratio
input int    InpMaxTrades       = 3;         // Max open trades

input group "=== STRUCTURE SETTINGS ==="
input int    InpStructureLookback = 50;      // BOS lookback bars
input int    InpFVGMinGap       = 5;         // Min FVG gap (points)
input int    InpLiquidityBars   = 20;        // Liquidity swing lookback

input group "=== DISPLAY SETTINGS ==="
input bool   InpShowFVG         = true;      // Show FVG zones
input bool   InpShowLiquidity   = true;      // Show liquidity levels
input bool   InpShowBOS         = true;      // Show BOS arrows
input bool   InpShowSignals     = true;      // Show buy/sell arrows
input color  InpBullishColor    = clrLimeGreen;   // Bullish color
input color  InpBearishColor    = clrRed;          // Bearish color
input color  InpFVGColor        = clrDodgerBlue;   // FVG zone color
input color  InpLiquidityColor  = clrGold;         // Liquidity color

input group "=== TRADING ==="
input bool   InpAutoTrade       = true;      // Enable auto trading
input ENUM_TIMEFRAMES InpHTF    = PERIOD_H4; // Higher timeframe

//--- Global Objects
CFVGDetector     g_fvg;
CLiquidityFinder g_liq;
CBOSDetector     g_bos;
CSignalEngine    g_signal;
CTrade           g_trade;

//--- State
datetime g_lastBarTime = 0;
int      g_totalSignals = 0;

//+------------------------------------------------------------------+
//| Expert initialization                                             |
//+------------------------------------------------------------------+
int OnInit()
  {
   Print("SmartMoney EA v1.0 initialized on ", Symbol(), " ", EnumToString(Period()));

   //--- Initialize modules
   g_fvg.Init(InpFVGMinGap, InpFVGColor, InpBullishColor, InpBearishColor);
   g_liq.Init(InpLiquidityBars, InpLiquidityColor);
   g_bos.Init(InpStructureLookback, InpBullishColor, InpBearishColor);
   g_signal.Init(InpRiskPercent, InpRRRatio);

   g_trade.SetExpertMagicNumber(202401);
   g_trade.SetDeviationInPoints(10);

   //--- Run initial scan
   ScanAndDraw();

   return INIT_SUCCEEDED;
  }

//+------------------------------------------------------------------+
//| Expert deinitialization                                           |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   ObjectsDeleteAll(0, "SMC_");
   Print("SmartMoney EA removed. Total signals generated: ", g_totalSignals);
  }

//+------------------------------------------------------------------+
//| Expert tick function                                              |
//+------------------------------------------------------------------+
void OnTick()
  {
   //--- Only process on new bar
   datetime currentBarTime = iTime(Symbol(), Period(), 0);
   if(currentBarTime == g_lastBarTime) return;
   g_lastBarTime = currentBarTime;

   //--- Scan market structure
   ScanAndDraw();

   //--- Generate signals
   ENUM_SIGNAL_TYPE signal = g_signal.GetSignal(
      g_bos.GetLastBOS(),
      g_fvg.GetNearestFVG(),
      g_liq.GetNearestLevel()
   );

   if(signal != SIGNAL_NONE)
     {
      g_totalSignals++;
      DrawSignalArrow(signal);

      if(InpAutoTrade)
         ExecuteTrade(signal);
     }

   //--- Manage open trades
   ManageOpenTrades();
  }

//+------------------------------------------------------------------+
//| Scan market and draw all SMC elements                             |
//+------------------------------------------------------------------+
void ScanAndDraw()
  {
   if(InpShowFVG)       g_fvg.Scan(Symbol(), Period(), 100);
   if(InpShowLiquidity) g_liq.Scan(Symbol(), Period(), InpLiquidityBars);
   if(InpShowBOS)       g_bos.Scan(Symbol(), Period(), InpStructureLookback);
  }

//+------------------------------------------------------------------+
//| Draw buy/sell arrow on chart                                      |
//+------------------------------------------------------------------+
void DrawSignalArrow(ENUM_SIGNAL_TYPE signal)
  {
   string name = "SMC_SIG_" + IntegerToString(g_totalSignals);
   double price;
   color  clr;
   int    code;
   string label;

   if(signal == SIGNAL_BUY)
     {
      price = iLow(Symbol(), Period(), 1) - 10 * Point();
      clr   = InpBullishColor;
      code  = 241; // Up arrow
      label = "BUY";
     }
   else
     {
      price = iHigh(Symbol(), Period(), 1) + 10 * Point();
      clr   = InpBearishColor;
      code  = 242; // Down arrow
      label = "SELL";
     }

   //--- Draw arrow
   ObjectCreate(0, name, OBJ_ARROW, 0, iTime(Symbol(), Period(), 1), price);
   ObjectSetInteger(0, name, OBJPROP_ARROWCODE, code);
   ObjectSetInteger(0, name, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, name, OBJPROP_WIDTH, 3);
   ObjectSetInteger(0, name, OBJPROP_ZORDER, 10);

   //--- Draw label
   string lblName = name + "_LBL";
   ObjectCreate(0, lblName, OBJ_TEXT, 0, iTime(Symbol(), Period(), 1), price);
   ObjectSetString(0, lblName, OBJPROP_TEXT, label);
   ObjectSetInteger(0, lblName, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, lblName, OBJPROP_FONTSIZE, 9);
   ObjectSetString(0, lblName, OBJPROP_FONT, "Arial Bold");

   ChartRedraw();

   Print(">>> ", label, " Signal at ", DoubleToString(price, _Digits),
         " | Bar: ", TimeToString(iTime(Symbol(), Period(), 1)));
  }

//+------------------------------------------------------------------+
//| Execute trade based on signal                                     |
//+------------------------------------------------------------------+
void ExecuteTrade(ENUM_SIGNAL_TYPE signal)
  {
   //--- Check max trades
   if(PositionsTotal() >= InpMaxTrades)
     {
      Print("Max trades reached. Skipping signal.");
      return;
     }

   double sl, tp, lotSize;
   double ask = SymbolInfoDouble(Symbol(), SYMBOL_ASK);
   double bid = SymbolInfoDouble(Symbol(), SYMBOL_BID);
   double atr = g_signal.GetATR(14);

   if(signal == SIGNAL_BUY)
     {
      sl      = bid - atr * 1.5;
      tp      = bid + atr * 1.5 * InpRRRatio;
      lotSize = g_signal.CalcLotSize(Symbol(), InpRiskPercent, MathAbs(bid - sl));
      g_trade.Buy(lotSize, Symbol(), ask, sl, tp, "SMC BUY");
     }
   else if(signal == SIGNAL_SELL)
     {
      sl      = ask + atr * 1.5;
      tp      = ask - atr * 1.5 * InpRRRatio;
      lotSize = g_signal.CalcLotSize(Symbol(), InpRiskPercent, MathAbs(sl - ask));
      g_trade.Sell(lotSize, Symbol(), bid, sl, tp, "SMC SELL");
     }
  }

//+------------------------------------------------------------------+
//| Manage open trades - trailing stop & partial close               |
//+------------------------------------------------------------------+
void ManageOpenTrades()
  {
   double atr = g_signal.GetATR(14);

   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      ulong ticket = PositionGetTicket(i);
      if(!PositionSelectByTicket(ticket)) continue;
      if(PositionGetString(POSITION_SYMBOL) != Symbol()) continue;
      if(PositionGetInteger(POSITION_MAGIC) != 202401) continue;

      double openPrice = PositionGetDouble(POSITION_PRICE_OPEN);
      double currentSL = PositionGetDouble(POSITION_SL);
      ENUM_POSITION_TYPE posType = (ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);

      //--- Trailing stop by ATR
      if(posType == POSITION_TYPE_BUY)
        {
         double newSL = SymbolInfoDouble(Symbol(), SYMBOL_BID) - atr;
         if(newSL > currentSL + Point())
            g_trade.PositionModify(ticket, newSL, PositionGetDouble(POSITION_TP));
        }
      else if(posType == POSITION_TYPE_SELL)
        {
         double newSL = SymbolInfoDouble(Symbol(), SYMBOL_ASK) + atr;
         if(newSL < currentSL - Point())
            g_trade.PositionModify(ticket, newSL, PositionGetDouble(POSITION_TP));
        }
     }
  }

//+------------------------------------------------------------------+
//| Chart event handler                                               |
//+------------------------------------------------------------------+
void OnChartEvent(const int id, const long& lparam,
                  const double& dparam, const string& sparam)
  {
   if(id == CHARTEVENT_CHART_CHANGE)
      ScanAndDraw();
  }
//+------------------------------------------------------------------+
