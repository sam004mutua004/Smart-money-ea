//+------------------------------------------------------------------+
//|                                                    Liquidity.mqh  |
//|              Liquidity Zone & Equal Highs/Lows Detection          |
//+------------------------------------------------------------------+
#ifndef LIQUIDITY_MQH
#define LIQUIDITY_MQH

//--- Liquidity level structure
struct LiquidityLevel
  {
   double   price;
   bool     isHigh;       // true = buy-side liq, false = sell-side liq
   bool     isSweep;      // has it been swept?
   datetime time;
   int      touches;
  };

//+------------------------------------------------------------------+
//| CLiquidityFinder — finds equal highs/lows and liquidity pools     |
//+------------------------------------------------------------------+
class CLiquidityFinder
  {
private:
   int            m_lookback;
   color          m_color;
   LiquidityLevel m_levels[];
   int            m_count;
   double         m_tolerance;   // pip tolerance for "equal" levels

   bool     IsSwingHigh(const string sym, ENUM_TIMEFRAMES tf, int bar, int left, int right);
   bool     IsSwingLow(const string sym, ENUM_TIMEFRAMES tf, int bar, int left, int right);
   void     DrawLevel(const LiquidityLevel &lvl, int index);
   void     CheckSweeps(const string sym, ENUM_TIMEFRAMES tf);

public:
            CLiquidityFinder() : m_lookback(20), m_count(0), m_tolerance(5.0) {}

   void     Init(int lookback, color clr);
   void     Scan(const string symbol, ENUM_TIMEFRAMES tf, int bars);
   LiquidityLevel GetNearestLevel();
  };

//+------------------------------------------------------------------+
void CLiquidityFinder::Init(int lookback, color clr)
  {
   m_lookback   = lookback;
   m_color      = clr;
   m_tolerance  = 5.0 * _Point;
   ArrayResize(m_levels, 0);
   m_count = 0;
  }

//+------------------------------------------------------------------+
//| Detect swing highs and lows as liquidity pools                    |
//+------------------------------------------------------------------+
void CLiquidityFinder::Scan(const string symbol, ENUM_TIMEFRAMES tf, int bars)
  {
   ObjectsDeleteAll(0, "SMC_LIQ_");
   ArrayResize(m_levels, 0);
   m_count = 0;

   int swingStrength = 3; // bars on each side for swing detection
   int limit = MathMin(bars, iBars(symbol, tf) - swingStrength - 1);

   for(int i = swingStrength; i < limit; i++)
     {
      //--- Swing High = Buy-side Liquidity
      if(IsSwingHigh(symbol, tf, i, swingStrength, swingStrength))
        {
         LiquidityLevel lvl;
         lvl.price   = iHigh(symbol, tf, i);
         lvl.isHigh  = true;
         lvl.isSweep = false;
         lvl.time    = iTime(symbol, tf, i);
         lvl.touches = 1;

         ArrayResize(m_levels, m_count + 1);
         m_levels[m_count] = lvl;
         DrawLevel(lvl, m_count);
         m_count++;
        }

      //--- Swing Low = Sell-side Liquidity
      if(IsSwingLow(symbol, tf, i, swingStrength, swingStrength))
        {
         LiquidityLevel lvl;
         lvl.price   = iLow(symbol, tf, i);
         lvl.isHigh  = false;
         lvl.isSweep = false;
         lvl.time    = iTime(symbol, tf, i);
         lvl.touches = 1;

         ArrayResize(m_levels, m_count + 1);
         m_levels[m_count] = lvl;
         DrawLevel(lvl, m_count);
         m_count++;
        }
     }

   //--- Mark swept levels
   CheckSweeps(symbol, tf);
  }

//+------------------------------------------------------------------+
bool CLiquidityFinder::IsSwingHigh(const string sym, ENUM_TIMEFRAMES tf,
                                    int bar, int left, int right)
  {
   double h = iHigh(sym, tf, bar);
   for(int i = 1; i <= left; i++)
      if(iHigh(sym, tf, bar + i) >= h) return false;
   for(int i = 1; i <= right; i++)
      if(iHigh(sym, tf, bar - i) >= h) return false;
   return true;
  }

//+------------------------------------------------------------------+
bool CLiquidityFinder::IsSwingLow(const string sym, ENUM_TIMEFRAMES tf,
                                   int bar, int left, int right)
  {
   double l = iLow(sym, tf, bar);
   for(int i = 1; i <= left; i++)
      if(iLow(sym, tf, bar + i) <= l) return false;
   for(int i = 1; i <= right; i++)
      if(iLow(sym, tf, bar - i) <= l) return false;
   return true;
  }

//+------------------------------------------------------------------+
//| Draw liquidity level as horizontal line                           |
//+------------------------------------------------------------------+
void CLiquidityFinder::DrawLevel(const LiquidityLevel &lvl, int index)
  {
   string name = "SMC_LIQ_" + IntegerToString(index);
   color  clr  = lvl.isSweep ? clrGray : m_color;
   string lbl  = lvl.isHigh ? "BSL" : "SSL"; // Buy-side / Sell-side Liquidity

   ObjectCreate(0, name, OBJ_HLINE, 0, 0, lvl.price);
   ObjectSetInteger(0, name, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, name, OBJPROP_STYLE, STYLE_DOT);
   ObjectSetInteger(0, name, OBJPROP_WIDTH, 1);

   //--- Label at level
   string lblName = name + "_L";
   ObjectCreate(0, lblName, OBJ_TEXT, 0, lvl.time, lvl.price);
   ObjectSetString(0, lblName, OBJPROP_TEXT, lbl + " " + DoubleToString(lvl.price, _Digits));
   ObjectSetInteger(0, lblName, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, lblName, OBJPROP_FONTSIZE, 7);
  }

//+------------------------------------------------------------------+
//| Check which levels have been swept by price                       |
//+------------------------------------------------------------------+
void CLiquidityFinder::CheckSweeps(const string sym, ENUM_TIMEFRAMES tf)
  {
   double currentHigh = iHigh(sym, tf, 1);
   double currentLow  = iLow(sym, tf, 1);

   for(int i = 0; i < m_count; i++)
     {
      if(m_levels[i].isHigh && currentHigh > m_levels[i].price)
         m_levels[i].isSweep = true;
      if(!m_levels[i].isHigh && currentLow < m_levels[i].price)
         m_levels[i].isSweep = true;
     }
  }

//+------------------------------------------------------------------+
//| Get nearest unswept liquidity level                               |
//+------------------------------------------------------------------+
LiquidityLevel CLiquidityFinder::GetNearestLevel()
  {
   LiquidityLevel nearest;
   nearest.price   = 0;
   nearest.isHigh  = false;
   nearest.isSweep = true;
   nearest.time    = 0;
   nearest.touches = 0;

   if(m_count == 0) return nearest;

   double currentPrice = SymbolInfoDouble(_Symbol, SYMBOL_BID);
   double minDist = DBL_MAX;

   for(int i = 0; i < m_count; i++)
     {
      if(m_levels[i].isSweep) continue;
      double dist = MathAbs(currentPrice - m_levels[i].price);
      if(dist < minDist)
        {
         minDist = dist;
         nearest = m_levels[i];
        }
     }
   return nearest;
  }

#endif
