//+------------------------------------------------------------------+
//|                                                          BOS.mqh  |
//|          Break of Structure (BOS) & Change of Character (CHoCH)   |
//+------------------------------------------------------------------+
#ifndef BOS_MQH
#define BOS_MQH

//--- Market bias enum
enum ENUM_MARKET_BIAS
  {
   BIAS_BULLISH,
   BIAS_BEARISH,
   BIAS_NEUTRAL
  };

//--- BOS event structure
struct BOSEvent
  {
   double            level;         // The broken level
   bool              isBullish;     // true = bullish BOS, false = bearish BOS
   bool              isCHoCH;       // Change of Character vs BOS
   datetime          time;
   ENUM_MARKET_BIAS  resultingBias;
  };

//+------------------------------------------------------------------+
//| CBOSDetector — detects Break of Structure and Change of Character |
//+------------------------------------------------------------------+
class CBOSDetector
  {
private:
   int              m_lookback;
   color            m_bullColor;
   color            m_bearColor;
   BOSEvent         m_events[];
   int              m_count;
   ENUM_MARKET_BIAS m_currentBias;
   double           m_lastSwingHigh;
   double           m_lastSwingLow;
   datetime         m_lastSwingHighTime;
   datetime         m_lastSwingLowTime;

   bool     IsSwingHigh(const string sym, ENUM_TIMEFRAMES tf, int bar);
   bool     IsSwingLow(const string sym, ENUM_TIMEFRAMES tf, int bar);
   void     DrawBOSLine(const BOSEvent &ev, int index);
   void     DrawStructureLabel(const BOSEvent &ev, int index);

public:
            CBOSDetector() : m_lookback(50), m_count(0),
                             m_currentBias(BIAS_NEUTRAL),
                             m_lastSwingHigh(0), m_lastSwingLow(0) {}

   void     Init(int lookback, color bullClr, color bearClr);
   void     Scan(const string symbol, ENUM_TIMEFRAMES tf, int bars);
   BOSEvent GetLastBOS();
   ENUM_MARKET_BIAS GetBias() { return m_currentBias; }
  };

//+------------------------------------------------------------------+
void CBOSDetector::Init(int lookback, color bullClr, color bearClr)
  {
   m_lookback  = lookback;
   m_bullColor = bullClr;
   m_bearColor = bearClr;
   ArrayResize(m_events, 0);
   m_count = 0;
  }

//+------------------------------------------------------------------+
//| Scan for BOS: price breaking previous swing high/low              |
//+------------------------------------------------------------------+
void CBOSDetector::Scan(const string symbol, ENUM_TIMEFRAMES tf, int bars)
  {
   ObjectsDeleteAll(0, "SMC_BOS_");
   ArrayResize(m_events, 0);
   m_count = 0;

   int limit = MathMin(bars, iBars(symbol, tf) - 4);

   double swingHighs[];
   double swingLows[];
   datetime swingHighTimes[];
   datetime swingLowTimes[];
   int hCount = 0, lCount = 0;

   ArrayResize(swingHighs, 0);
   ArrayResize(swingLows, 0);
   ArrayResize(swingHighTimes, 0);
   ArrayResize(swingLowTimes, 0);

   //--- First pass: collect all swing points
   for(int i = 3; i < limit; i++)
     {
      if(IsSwingHigh(symbol, tf, i))
        {
         ArrayResize(swingHighs, hCount + 1);
         ArrayResize(swingHighTimes, hCount + 1);
         swingHighs[hCount]     = iHigh(symbol, tf, i);
         swingHighTimes[hCount] = iTime(symbol, tf, i);
         hCount++;
        }
      if(IsSwingLow(symbol, tf, i))
        {
         ArrayResize(swingLows, lCount + 1);
         ArrayResize(swingLowTimes, lCount + 1);
         swingLows[lCount]     = iLow(symbol, tf, i);
         swingLowTimes[lCount] = iTime(symbol, tf, i);
         lCount++;
        }
     }

   //--- Second pass: detect BOS events
   for(int i = 1; i < limit; i++)
     {
      double closePrice = iClose(symbol, tf, i);
      double highPrice  = iHigh(symbol, tf, i);
      double lowPrice   = iLow(symbol, tf, i);

      //--- Check bullish BOS: close above previous swing high
      for(int h = 0; h < hCount; h++)
        {
         if(swingHighTimes[h] > iTime(symbol, tf, i)) continue;
         if(closePrice > swingHighs[h] && highPrice > swingHighs[h])
           {
            BOSEvent ev;
            ev.level        = swingHighs[h];
            ev.isBullish    = true;
            ev.isCHoCH      = (m_currentBias == BIAS_BEARISH);
            ev.time         = iTime(symbol, tf, i);
            ev.resultingBias = BIAS_BULLISH;

            m_currentBias = BIAS_BULLISH;
            ArrayResize(m_events, m_count + 1);
            m_events[m_count] = ev;
            DrawBOSLine(ev, m_count);
            DrawStructureLabel(ev, m_count);
            m_count++;
            break;
           }
        }

      //--- Check bearish BOS: close below previous swing low
      for(int l = 0; l < lCount; l++)
        {
         if(swingLowTimes[l] > iTime(symbol, tf, i)) continue;
         if(closePrice < swingLows[l] && lowPrice < swingLows[l])
           {
            BOSEvent ev;
            ev.level         = swingLows[l];
            ev.isBullish     = false;
            ev.isCHoCH       = (m_currentBias == BIAS_BULLISH);
            ev.time          = iTime(symbol, tf, i);
            ev.resultingBias = BIAS_BEARISH;

            m_currentBias = BIAS_BEARISH;
            ArrayResize(m_events, m_count + 1);
            m_events[m_count] = ev;
            DrawBOSLine(ev, m_count);
            DrawStructureLabel(ev, m_count);
            m_count++;
            break;
           }
        }
     }
  }

//+------------------------------------------------------------------+
bool CBOSDetector::IsSwingHigh(const string sym, ENUM_TIMEFRAMES tf, int bar)
  {
   double h = iHigh(sym, tf, bar);
   return (iHigh(sym, tf, bar + 1) < h && iHigh(sym, tf, bar + 2) < h &&
           iHigh(sym, tf, bar - 1) < h && iHigh(sym, tf, bar - 2) < h);
  }

//+------------------------------------------------------------------+
bool CBOSDetector::IsSwingLow(const string sym, ENUM_TIMEFRAMES tf, int bar)
  {
   double l = iLow(sym, tf, bar);
   return (iLow(sym, tf, bar + 1) > l && iLow(sym, tf, bar + 2) > l &&
           iLow(sym, tf, bar - 1) > l && iLow(sym, tf, bar - 2) > l);
  }

//+------------------------------------------------------------------+
//| Draw BOS level line                                               |
//+------------------------------------------------------------------+
void CBOSDetector::DrawBOSLine(const BOSEvent &ev, int index)
  {
   string name = "SMC_BOS_LINE_" + IntegerToString(index);
   color  clr  = ev.isBullish ? m_bullColor : m_bearColor;

   ObjectCreate(0, name, OBJ_HLINE, 0, 0, ev.level);
   ObjectSetInteger(0, name, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, name, OBJPROP_STYLE, ev.isCHoCH ? STYLE_SOLID : STYLE_DASH);
   ObjectSetInteger(0, name, OBJPROP_WIDTH, ev.isCHoCH ? 2 : 1);
  }

//+------------------------------------------------------------------+
//| Draw BOS/CHoCH label                                              |
//+------------------------------------------------------------------+
void CBOSDetector::DrawStructureLabel(const BOSEvent &ev, int index)
  {
   string name  = "SMC_BOS_LBL_" + IntegerToString(index);
   string text  = ev.isCHoCH ? "CHoCH" : "BOS";
   color  clr   = ev.isBullish ? m_bullColor : m_bearColor;
   double offset = ev.isBullish ? 5 * _Point : -5 * _Point;

   ObjectCreate(0, name, OBJ_TEXT, 0, ev.time, ev.level + offset);
   ObjectSetString(0, name, OBJPROP_TEXT, text);
   ObjectSetInteger(0, name, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, name, OBJPROP_FONTSIZE, 8);
   ObjectSetString(0, name, OBJPROP_FONT, "Arial Bold");
  }

//+------------------------------------------------------------------+
//| Get the most recent BOS event                                     |
//+------------------------------------------------------------------+
BOSEvent CBOSDetector::GetLastBOS()
  {
   BOSEvent empty;
   empty.level         = 0;
   empty.isBullish     = false;
   empty.isCHoCH       = false;
   empty.time          = 0;
   empty.resultingBias = BIAS_NEUTRAL;

   if(m_count == 0) return empty;
   return m_events[m_count - 1];
  }

#endif
