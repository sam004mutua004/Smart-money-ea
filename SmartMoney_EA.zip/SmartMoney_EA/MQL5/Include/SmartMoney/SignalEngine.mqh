//+------------------------------------------------------------------+
//|                                                 SignalEngine.mqh  |
//|           Signal Engine — Combines FVG + Liquidity + BOS          |
//+------------------------------------------------------------------+
#ifndef SIGNALENGINE_MQH
#define SIGNALENGINE_MQH

#include "FVG.mqh"
#include "Liquidity.mqh"
#include "BOS.mqh"

//--- Signal types
enum ENUM_SIGNAL_TYPE
  {
   SIGNAL_NONE  = 0,
   SIGNAL_BUY   = 1,
   SIGNAL_SELL  = -1
  };

//+------------------------------------------------------------------+
//| CSignalEngine — merges all SMC confluences into a signal          |
//+------------------------------------------------------------------+
class CSignalEngine
  {
private:
   double m_riskPercent;
   double m_rrRatio;
   int    m_atrHandle;
   double m_atrBuffer[];

   bool   IsBullishSetup(const BOSEvent &bos, const FVGZone &fvg, const LiquidityLevel &liq);
   bool   IsBearishSetup(const BOSEvent &bos, const FVGZone &fvg, const LiquidityLevel &liq);

public:
          CSignalEngine() : m_riskPercent(1.0), m_rrRatio(2.0), m_atrHandle(INVALID_HANDLE) {}

   void   Init(double riskPct, double rrRatio);
   ENUM_SIGNAL_TYPE GetSignal(const BOSEvent &bos, const FVGZone &fvg, const LiquidityLevel &liq);
   double GetATR(int period);
   double CalcLotSize(const string symbol, double riskPct, double slPoints);
  };

//+------------------------------------------------------------------+
void CSignalEngine::Init(double riskPct, double rrRatio)
  {
   m_riskPercent = riskPct;
   m_rrRatio     = rrRatio;
   m_atrHandle   = iATR(_Symbol, _Period, 14);
   ArraySetAsSeries(m_atrBuffer, true);
  }

//+------------------------------------------------------------------+
//| Core logic: require BOS + FVG + Liquidity confluence              |
//+------------------------------------------------------------------+
ENUM_SIGNAL_TYPE CSignalEngine::GetSignal(
   const BOSEvent &bos,
   const FVGZone &fvg,
   const LiquidityLevel &liq)
  {
   if(bos.level == 0) return SIGNAL_NONE; // No BOS detected

   double currentPrice = SymbolInfoDouble(_Symbol, SYMBOL_BID);
   double atr = GetATR(14);

   if(IsBullishSetup(bos, fvg, liq))
      return SIGNAL_BUY;

   if(IsBearishSetup(bos, fvg, liq))
      return SIGNAL_SELL;

   return SIGNAL_NONE;
  }

//+------------------------------------------------------------------+
//| Bullish confluence:                                               |
//|  1. BOS to the upside (bullish)                                   |
//|  2. Price inside or near a bullish FVG                            |
//|  3. Sell-side liquidity nearby (swept or price approaching it)    |
//+------------------------------------------------------------------+
bool CSignalEngine::IsBullishSetup(const BOSEvent &bos, const FVGZone &fvg, const LiquidityLevel &liq)
  {
   double price = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
   double atr   = GetATR(14);

   //--- Condition 1: Last BOS was bullish
   if(!bos.isBullish) return false;

   //--- Condition 2: Price is inside or near a bullish FVG (within 1 ATR)
   bool inFVG = false;
   if(fvg.low != 0 && fvg.isBullish)
      inFVG = (price >= fvg.low - atr && price <= fvg.high + atr);

   //--- Condition 3: Sell-side liquidity nearby (within 2 ATR below)
   bool nearSSL = false;
   if(liq.price != 0 && !liq.isHigh)
      nearSSL = (MathAbs(price - liq.price) < atr * 2.0);

   //--- All confluences required
   return (inFVG && nearSSL);
  }

//+------------------------------------------------------------------+
//| Bearish confluence:                                               |
//|  1. BOS to the downside (bearish)                                 |
//|  2. Price inside or near a bearish FVG                            |
//|  3. Buy-side liquidity nearby (swept or price approaching it)     |
//+------------------------------------------------------------------+
bool CSignalEngine::IsBearishSetup(const BOSEvent &bos, const FVGZone &fvg, const LiquidityLevel &liq)
  {
   double price = SymbolInfoDouble(_Symbol, SYMBOL_BID);
   double atr   = GetATR(14);

   //--- Condition 1: Last BOS was bearish
   if(bos.isBullish) return false;

   //--- Condition 2: Price is inside or near a bearish FVG (within 1 ATR)
   bool inFVG = false;
   if(fvg.high != 0 && !fvg.isBullish)
      inFVG = (price <= fvg.high + atr && price >= fvg.low - atr);

   //--- Condition 3: Buy-side liquidity nearby (within 2 ATR above)
   bool nearBSL = false;
   if(liq.price != 0 && liq.isHigh)
      nearBSL = (MathAbs(price - liq.price) < atr * 2.0);

   //--- All confluences required
   return (inFVG && nearBSL);
  }

//+------------------------------------------------------------------+
//| Get current ATR value                                             |
//+------------------------------------------------------------------+
double CSignalEngine::GetATR(int period)
  {
   if(m_atrHandle == INVALID_HANDLE)
      m_atrHandle = iATR(_Symbol, _Period, period);

   if(CopyBuffer(m_atrHandle, 0, 0, 3, m_atrBuffer) <= 0)
      return 10 * _Point; // fallback

   return m_atrBuffer[1];
  }

//+------------------------------------------------------------------+
//| Calculate lot size based on risk % and SL distance                |
//+------------------------------------------------------------------+
double CSignalEngine::CalcLotSize(const string symbol, double riskPct, double slDistance)
  {
   if(slDistance <= 0) return 0.01;

   double accountBalance = AccountInfoDouble(ACCOUNT_BALANCE);
   double riskAmount     = accountBalance * riskPct / 100.0;
   double tickValue      = SymbolInfoDouble(symbol, SYMBOL_TRADE_TICK_VALUE);
   double tickSize       = SymbolInfoDouble(symbol, SYMBOL_TRADE_TICK_SIZE);
   double minLot         = SymbolInfoDouble(symbol, SYMBOL_VOLUME_MIN);
   double maxLot         = SymbolInfoDouble(symbol, SYMBOL_VOLUME_MAX);
   double lotStep        = SymbolInfoDouble(symbol, SYMBOL_VOLUME_STEP);

   if(tickValue == 0 || tickSize == 0) return minLot;

   double valuePerLot = (slDistance / tickSize) * tickValue;
   if(valuePerLot == 0) return minLot;

   double lots = riskAmount / valuePerLot;
   lots = MathFloor(lots / lotStep) * lotStep;
   lots = MathMax(minLot, MathMin(maxLot, lots));

   return NormalizeDouble(lots, 2);
  }

#endif
