//+------------------------------------------------------------------+
//|                                                          FVG.mqh  |
//|                     Fair Value Gap Detection Module               |
//+------------------------------------------------------------------+
#ifndef FVG_MQH
#define FVG_MQH

//--- FVG structure
struct FVGZone
  {
   double   high;
   double   low;
   bool     isBullish;
   datetime time;
   bool     isFilled;
  };

//+------------------------------------------------------------------+
//| CFVGDetector — detects and draws Fair Value Gaps                  |
//+------------------------------------------------------------------+
class CFVGDetector
  {
private:
   int      m_minGap;
   color    m_zoneColor;
   color    m_bullColor;
   color    m_bearColor;
   FVGZone  m_zones[];
   int      m_count;

   void     DrawFVGZone(const FVGZone &zone, int index);
   bool     IsFilled(const FVGZone &zone, const string symbol, ENUM_TIMEFRAMES tf);

public:
            CFVGDetector() : m_minGap(5), m_count(0) {}

   void     Init(int minGap, color zoneClr, color bullClr, color bearClr);
   void     Scan(const string symbol, ENUM_TIMEFRAMES tf, int bars);
   FVGZone  GetNearestFVG();
  };

//+------------------------------------------------------------------+
void CFVGDetector::Init(int minGap, color zoneClr, color bullClr, color bearClr)
  {
   m_minGap   = minGap;
   m_zoneColor = zoneClr;
   m_bullColor = bullClr;
   m_bearColor = bearClr;
   ArrayResize(m_zones, 0);
   m_count = 0;
  }

//+------------------------------------------------------------------+
//| Scan for FVGs: 3-candle pattern where candle[1] leaves a gap      |
//+------------------------------------------------------------------+
void CFVGDetector::Scan(const string symbol, ENUM_TIMEFRAMES tf, int bars)
  {
   //--- Clear old FVG objects
   ObjectsDeleteAll(0, "SMC_FVG_");
   ArrayResize(m_zones, 0);
   m_count = 0;

   int limit = MathMin(bars, iBars(symbol, tf) - 2);

   for(int i = 2; i < limit; i++)
     {
      double high1 = iHigh(symbol, tf, i + 1);  // Candle before gap
      double low1  = iLow(symbol, tf, i + 1);
      double high2 = iHigh(symbol, tf, i - 1);  // Candle after gap
      double low2  = iLow(symbol, tf, i - 1);
      double mid   = iClose(symbol, tf, i);

      double gapUp   = low2 - high1;   // Bullish FVG
      double gapDown = low1 - high2;   // Bearish FVG

      FVGZone zone;
      zone.time    = iTime(symbol, tf, i);
      zone.isFilled = false;

      //--- Bullish FVG: gap between high of i+1 and low of i-1
      if(gapUp > m_minGap * _Point)
        {
         zone.high      = low2;
         zone.low       = high1;
         zone.isBullish = true;

         if(!IsFilled(zone, symbol, tf))
           {
            ArrayResize(m_zones, m_count + 1);
            m_zones[m_count] = zone;
            DrawFVGZone(zone, m_count);
            m_count++;
           }
        }
      //--- Bearish FVG: gap between low of i+1 and high of i-1
      else if(gapDown > m_minGap * _Point)
        {
         zone.high      = low1;
         zone.low       = high2;
         zone.isBullish = false;

         if(!IsFilled(zone, symbol, tf))
           {
            ArrayResize(m_zones, m_count + 1);
            m_zones[m_count] = zone;
            DrawFVGZone(zone, m_count);
            m_count++;
           }
        }
     }
  }

//+------------------------------------------------------------------+
//| Draw FVG zone as a rectangle on the chart                         |
//+------------------------------------------------------------------+
void CFVGDetector::DrawFVGZone(const FVGZone &zone, int index)
  {
   string name  = "SMC_FVG_" + IntegerToString(index);
   datetime t1  = zone.time;
   datetime t2  = zone.time + PeriodSeconds() * 10;
   color    clr = zone.isBullish ? m_bullColor : m_bearColor;

   ObjectCreate(0, name, OBJ_RECTANGLE, 0, t1, zone.high, t2, zone.low);
   ObjectSetInteger(0, name, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, name, OBJPROP_STYLE, STYLE_DASH);
   ObjectSetInteger(0, name, OBJPROP_WIDTH, 1);
   ObjectSetInteger(0, name, OBJPROP_FILL, true);
   ObjectSetInteger(0, name, OBJPROP_BACK, true);
   ObjectSetDouble(0, name, OBJPROP_TRANSPARENCY, 80);

   //--- Label
   string lblName = name + "_L";
   ObjectCreate(0, lblName, OBJ_TEXT, 0, t1, zone.high);
   ObjectSetString(0, lblName, OBJPROP_TEXT, zone.isBullish ? "BFVG" : "SFVG");
   ObjectSetInteger(0, lblName, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, lblName, OBJPROP_FONTSIZE, 7);
  }

//+------------------------------------------------------------------+
//| Check if FVG has been filled by price                             |
//+------------------------------------------------------------------+
bool CFVGDetector::IsFilled(const FVGZone &zone, const string symbol, ENUM_TIMEFRAMES tf)
  {
   double currentPrice = iClose(symbol, tf, 0);
   if(zone.isBullish && currentPrice < zone.low)  return true;
   if(!zone.isBullish && currentPrice > zone.high) return true;
   return false;
  }

//+------------------------------------------------------------------+
//| Get the nearest unfilled FVG relative to current price            |
//+------------------------------------------------------------------+
FVGZone CFVGDetector::GetNearestFVG()
  {
   FVGZone nearest;
   nearest.high = 0;
   nearest.low  = 0;
   nearest.isBullish = false;
   nearest.time = 0;
   nearest.isFilled = true;

   if(m_count == 0) return nearest;

   double currentPrice = SymbolInfoDouble(_Symbol, SYMBOL_BID);
   double minDist = DBL_MAX;

   for(int i = 0; i < m_count; i++)
     {
      if(m_zones[i].isFilled) continue;
      double midZone = (m_zones[i].high + m_zones[i].low) / 2.0;
      double dist    = MathAbs(currentPrice - midZone);
      if(dist < minDist)
        {
         minDist = dist;
         nearest = m_zones[i];
        }
     }
   return nearest;
  }

#endif
